<?php
    wp_enqueue_style( 'style-name', get_stylesheet_uri() );
    wp_enqueue_style( 'style-boot', get_template_directory_uri() . '/asetess/css/bootstrap.min.css');

    wp_enqueue_script( 'script-name', get_template_directory_uri() . '/asetess/js/bootstrap.bundle.min.js', array(), '1.0.0', true );

    add_theme_support( 'title-tag' );
    add_theme_support( 'custom-logo');

    register_nav_menus([
        'TM'=>'primary',
        'FM'=>'footer',
    ]);

    register_sidebar([
        'name'=>'main Banner',
        'id'=>'mainbanner',
        'before_widget'=>'',
        'after_widget'=>'',

    ]);
    register_sidebar([
        'name'=>'main sidber',
        'id'=>'mainsidber',
        'before_widget'=>'',
        'after_widget'=>'',

    ]);