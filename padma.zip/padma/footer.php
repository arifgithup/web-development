<!-- footer part start -->

<footer class="footer1 ">
        <div class="container  ">
          <div class="row footer_top">
            <div class="col-sm-6 lft1">
              <h5>CONTACT US</h5>
              <ul>
                <li id="icon1">Address: Office of the Project 
                  Director Padma Multipurpose Bridge Project 4th floor,
                   Setu Bhaban, New Airport Road, Banani, Dhaka-1212</li>
                <li id="icon2">Telephone: +880 2 55040451</li>
                <li id="icon3">Fax: +880 2 55040477</li>
                <li id="icon4">Email: <a href="#">padmabridgeweb@gmail.com</a></li>
              </ul>
              
            </div>
            <div class="col-sm-6 footer_right">
              <h5>IMPORTANT LINKS</h5>
              <ul>
                <li>IMPORTANT LINKS Prime Minister's Office</li>
                <li>PMIS</li>
                <li>Bangladesh Bridge Authority</li>
                <li>Bridges Division</li>
                <li>Roads and Highways Department</li>
                <li>Cabinet Division</li>
                <li>Ministry of Public Administration</li>
                <li>National Web Portal</li>
              </ul>
              
            </div>
          </div>


          <div class="row footer_buttom">
            <div class="col-sm-6">
              <a href="#"><p>POWERED BY SOLUTION ART LTD</p></a>
            </div>
            <div class="col-sm-6 text-end">
              <a href="#"><p>COPYRIGHT © 2015. BANGLADESH BRIDGE AUTHORITY</p></a>
            </div>
          </div>
        </div>

      </footer>
<!-- footer part end -->
