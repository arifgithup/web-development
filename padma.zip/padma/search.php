<?php get_header();?>

<section class="container mt-5 mb-5 text-center">
 <h2>hi bangladesh</h2>

</section>


<?php get_footer();?>